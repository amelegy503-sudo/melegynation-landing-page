# Melegy: website

Static site. No build step. Open `index.html` in a browser, or upload the whole folder to Netlify, Vercel, Cloudflare Pages or any host.

## Folder
- `index.html`: all content (search for `[` to find every placeholder)
- `css/styles.css`: design tokens at the top (`:root`)
- `js/main.js`: **links and form endpoint live in the `LINKS` block at the top**
- `images/`: drop photos here (see `images/README.txt` for exact filenames and sizes)
- `favicon.svg`: placeholder "M" mark. Replace with your own.

## Before launch
1. **Links** (`js/main.js`): `[APPLICATION_FORM_URL]`, `[CALENDLY_URL]`, `[WHATSAPP_URL]`, `[INSTAGRAM_URL]` (x2: @melegyy and @melegynation), `[EMAIL]`.
   Until a link is set it is inert and the form says "not connected".
2. **Application form**: set `LINKS.application` to an endpoint that accepts a POST (Formspree, Basin, Getform, or your own). Submit a real test application.
3. **Photos**: add the files in `images/`. Update each `alt` in `index.html` to describe your photo.
4. **Placeholders in index.html** (highlighted yellow-blue): minimum term / cancellation / payment methods, check-in day, WhatsApp hours, response time, time zones, years coaching / workplace / other certifications, "how I started" line, all case studies and testimonials.
5. **SEO**: uncomment and fill `canonical`, `og:url`, `og:image` (1200x630) and `apple-touch-icon` in the `<head>`.
6. **Privacy**: if you collect data from EU/UK visitors, add a privacy policy and link it near the form.
7. **Remove the "[PLACEHOLDER...]" line** in the Results section once you have real case studies. Never publish a name, photo or message without written permission.

## Open business question
Are programs (Section 5) and rehabilitation/corrective programs (Section 6) sold on their own, or only inside the 50 OMR online coaching? The page currently shows one price (coaching). If standalone programs exist, add their price and link in `#programs` / `#rehab`.
